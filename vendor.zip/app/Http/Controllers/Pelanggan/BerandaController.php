<?php

namespace App\Http\Controllers\Pelanggan;

use App\Http\Controllers\Controller;
use App\Models\Ulasan;
use Illuminate\Http\Request;

class BerandaController extends Controller
{
    public function index()
    {
        $ulasan = Ulasan::with([
            'user', 
            'order.orderItems.product' 
        ])->latest()->take(12)->get(); 
        return view('pelanggan.beranda', compact('ulasan'));
    }
}
